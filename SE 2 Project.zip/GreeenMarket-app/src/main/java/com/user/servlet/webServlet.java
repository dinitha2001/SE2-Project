package com.user.servlet;

public @interface webServlet {

	String value();

}
